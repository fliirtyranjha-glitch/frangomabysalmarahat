
import React, { useState, useEffect } from 'react';
import { View, Product, CartItem, Order, OrderStatus, DashboardStats, CATEGORIES, DiscountCode, Banner, SiteSettings, Review } from './types';
import { Navbar } from './components/Navbar';
import { StoreFront } from './components/StoreFront';
import { AdminDashboard } from './components/AdminDashboard';
import { InfoPages } from './components/InfoPages';
import { ProductDetail } from './components/ProductDetail';
import { Auth } from './components/Auth';
import { sendOrderEmails } from './services/emailService';
import { Trash2, ArrowRight, CheckCircle, ShoppingBag, Tag, X, Loader2, Instagram, Truck } from 'lucide-react';

// Mock Data - Reset for Live Deployment
const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Maverick Ember',
    price: 85.00,
    category: 'Fragrances',
    description: 'A bold fragrance with notes of amber and musk, perfect for evening wear.',
    image: 'https://images.unsplash.com/photo-1594035910387-fea47794261e?q=80&w=600&auto=format&fit=crop',
    featured: true,
    stock: 50,
    discount: 10,
    saleEndTime: new Date(Date.now() + 86400000 * 1.5).toISOString(),
    reviews: []
  },
  {
    id: '2',
    name: 'Legacy Oud',
    price: 120.00,
    category: 'Fragrances',
    description: 'A timeless classic scent featuring oud and sandalwood tones.',
    image: 'https://images.unsplash.com/photo-1615160699401-49b07802b8d0?q=80&w=600&auto=format&fit=crop',
    featured: true,
    stock: 30,
    reviews: []
  }
];

const INITIAL_BANNERS: Banner[] = [
  {
    id: '1',
    title: 'LUXURY SCENTS',
    subtitle: 'Discover the essence of elegance with Fragoma.',
    image: 'https://images.unsplash.com/photo-1615529328331-f8917597711f?q=80&w=1600&auto=format&fit=crop'
  }
];

const INITIAL_SETTINGS: SiteSettings = {
  siteName: 'Fragoma',
  tagline: 'Pure Natural Essence',
  logoImage: null,
  contactEmail: 'info@fragoma.ca',
  contactPhone: '+1 (555) 010-9999',
  instagramUrl: 'https://www.instagram.com/fragomabysalmarahat/',
  footerDescription: 'Experience the essence of luxury with our premium collection of curated fragrances.',
  shippingCost: 250,
  freeShippingThreshold: 5000,
  topBarMessage: 'Welcome to Fragoma By Salma Rahat | Free Shipping on orders over $50 | Shop our new exclusive collection ✨'
};

const INITIAL_STATS: DashboardStats = {
  totalViews: 0,
  uniqueVisitors: 0,
  totalSales: 0,
  totalOrders: 0,
  totalCartActions: 0
};

const INITIAL_ORDERS: Order[] = [];

const DISCOUNT_CODES: DiscountCode[] = [
  { code: 'SAVE10', type: 'PERCENTAGE', value: 10 },
  { code: 'WELCOME20', type: 'PERCENTAGE', value: 20 },
  { code: 'FRAGOMA20', type: 'FIXED', value: 20 },
];

const getLocalStorage = <T,>(key: string, initialValue: T): T => {
  try {
    const item = window.localStorage.getItem(key);
    return item ? JSON.parse(item) : initialValue;
  } catch (error) {
    console.warn(`Error reading localStorage key "${key}":`, error);
    return initialValue;
  }
};

const setLocalStorage = <T,>(key: string, value: T) => {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.warn(`Error writing localStorage key "${key}":`, error);
  }
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.STORE);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  
  const [products, setProducts] = useState<Product[]>(() => getLocalStorage('fragoma_products_v3', INITIAL_PRODUCTS));
  const [banners, setBanners] = useState<Banner[]>(() => getLocalStorage('fragoma_banners_v3', INITIAL_BANNERS));
  const [settings, setSettings] = useState<SiteSettings>(() => getLocalStorage('fragoma_settings_v3', INITIAL_SETTINGS));
  const [orders, setOrders] = useState<Order[]>(() => getLocalStorage('fragoma_orders_v3', INITIAL_ORDERS));
  const [stats, setStats] = useState<DashboardStats>(() => getLocalStorage('fragoma_stats_v3', INITIAL_STATS));
  
  const [cart, setCart] = useState<CartItem[]>([]);

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [guestAddress, setGuestAddress] = useState('');

  const [discountInput, setDiscountInput] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<DiscountCode | null>(null);
  const [discountError, setDiscountError] = useState('');
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);

  useEffect(() => { setLocalStorage('fragoma_products_v3', products); }, [products]);
  useEffect(() => { setLocalStorage('fragoma_banners_v3', banners); }, [banners]);
  useEffect(() => { setLocalStorage('fragoma_settings_v3', settings); }, [settings]);
  useEffect(() => { setLocalStorage('fragoma_orders_v3', orders); }, [orders]);
  useEffect(() => { setLocalStorage('fragoma_stats_v3', stats); }, [stats]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('product');
    if (productId) {
      const product = products.find(p => p.id === productId);
      if (product) {
        setSelectedProductId(productId);
        setCurrentView(View.PRODUCT_DETAIL);
      }
    }
  }, [products]);

  useEffect(() => {
    const newStats = {
      ...stats,
      totalViews: stats.totalViews + 1,
      uniqueVisitors: stats.uniqueVisitors + (Math.random() > 0.8 ? 1 : 0)
    };
    setStats(newStats);
    window.scrollTo(0, 0);
  }, [currentView, selectedProductId]);

  const handleLogin = (email: string, role: 'ADMIN' | 'CUSTOMER') => {
    setIsAuthenticated(true);
    setUserEmail(email);
    if (role === 'ADMIN') {
      setIsAdmin(true);
      setCurrentView(View.ADMIN);
    } else {
      setIsAdmin(false);
      setCurrentView(View.STORE);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setIsAdmin(false);
    setUserEmail('');
    setGuestName('');
    setGuestEmail('');
    setGuestAddress('');
    setGuestPhone('');
    setCurrentView(View.LOGIN);
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts(prev => [newProduct, ...prev]);
  };

  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const handleAddReview = (productId: string, review: Review) => {
    setProducts(prev => prev.map(p => 
      p.id === productId ? { ...p, reviews: [review, ...(p.reviews || [])] } : p
    ));
  };

  const handleProductClick = (product: Product) => {
    setSelectedProductId(product.id);
    setCurrentView(View.PRODUCT_DETAIL);
  };

  const handleAddBanner = (newBanner: Banner) => {
    setBanners(prev => [...prev, newBanner]);
  };

  const handleDeleteBanner = (id: string) => {
    setBanners(prev => prev.filter(b => b.id !== id));
  };

  const handleUpdateSettings = (newSettings: SiteSettings) => {
      setSettings(newSettings);
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    ));
  };

  const handleAddToCart = (product: Product) => {
    setStats(prev => ({ ...prev, totalCartActions: prev.totalCartActions + 1 }));
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
        if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
    }));
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const applyDiscount = () => {
    setDiscountError('');
    const code = discountInput.trim().toUpperCase();
    if (!code) return;
    const validCode = DISCOUNT_CODES.find(d => d.code === code);
    if (validCode) {
      setAppliedDiscount(validCode);
      setDiscountInput('');
    } else {
      setDiscountError('Invalid code');
    }
  };

  const discountAmount = appliedDiscount 
    ? (appliedDiscount.type === 'PERCENTAGE' ? subtotal * (appliedDiscount.value / 100) : appliedDiscount.value) 
    : 0;
  const isFreeShipping = settings.freeShippingThreshold > 0 && subtotal >= settings.freeShippingThreshold;
  const currentShippingCost = isFreeShipping ? 0 : settings.shippingCost;
  const finalTotal = Math.max(0, subtotal - discountAmount + currentShippingCost);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    setIsProcessingCheckout(true);
    const newOrder: Order = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: guestName,
      email: guestEmail,
      customerPhone: guestPhone,
      shippingAddress: guestAddress,
      items: [...cart],
      subtotal: subtotal,
      discountAmount: discountAmount,
      discountCode: appliedDiscount?.code,
      shippingCost: currentShippingCost,
      total: finalTotal,
      status: OrderStatus.PENDING,
      date: new Date().toISOString()
    };
    await sendOrderEmails(newOrder);
    setOrders([newOrder, ...orders]);
    setStats({
      ...stats,
      totalSales: stats.totalSales + finalTotal,
      totalOrders: stats.totalOrders + 1
    });
    setCart([]);
    setAppliedDiscount(null);
    if (!isAuthenticated) { setGuestName(''); setGuestEmail(''); setGuestPhone(''); setGuestAddress(''); }
    setIsProcessingCheckout(false);
    alert(`Order ${newOrder.id} placed successfully!`);
    setCurrentView(View.STORE);
  };

  const CartView = () => (
      <div className="max-w-7xl auto pt-10 pb-20 px-4 sm:px-6 lg:px-8 min-h-screen bg-gray-50">
        <h1 className="text-3xl font-serif tracking-tight text-[#D4AF37] sm:text-4xl mb-8 border-b pb-4">Shopping Cart</h1>
        {cart.length === 0 ? (
            <div className="text-center py-16 bg-white border border-gray-100 shadow-sm">
                <ShoppingBag className="h-16 w-16 text-[#D4AF37] mx-auto mb-4" />
                <p className="text-gray-900 font-serif text-lg">Your cart is empty</p>
                <button onClick={() => setCurrentView(View.STORE)} className="mt-6 inline-flex items-center px-6 py-3 border border-transparent text-sm font-medium text-white bg-[#D4AF37] hover:bg-black uppercase tracking-wider transition-all">
                    Continue Shopping
                </button>
            </div>
        ) : (
            <form onSubmit={handleCheckout} className="mt-12 lg:grid lg:grid-cols-12 lg:gap-x-12 lg:items-start xl:gap-x-16">
              <section aria-labelledby="cart-heading" className="lg:col-span-7">
                <ul className="border-t border-b border-gray-200 divide-y divide-gray-200 bg-white shadow-sm mb-8">
                {cart.map((item) => (
                    <li key={item.id} className="flex py-6 px-4 sm:py-10">
                    <div className="flex-shrink-0">
                        <img src={item.image} alt={item.name} className="w-24 h-24 object-center object-cover sm:w-32 sm:h-32 border border-gray-100" />
                    </div>
                    <div className="ml-4 flex-1 flex flex-col justify-between sm:ml-6">
                        <div className="relative pr-9 sm:grid sm:grid-cols-2 sm:gap-x-6 sm:pr-0">
                        <div>
                            <h3 className="font-serif text-lg font-medium text-gray-900 uppercase">{item.name}</h3>
                            <p className="mt-1 text-sm font-medium text-[#D4AF37]">${item.price.toFixed(2)}</p>
                        </div>
                        <div className="mt-4 sm:mt-0 sm:pr-9">
                            <div className="flex items-center space-x-3 border border-gray-300 w-max bg-white">
                                <button type="button" onClick={() => updateQuantity(item.id, -1)} className="p-2 bg-white text-gray-900">-</button>
                                <span className="text-gray-900 font-medium px-2">{item.quantity}</span>
                                <button type="button" onClick={() => updateQuantity(item.id, 1)} className="p-2 bg-white text-gray-900">+</button>
                            </div>
                            <div className="absolute top-0 right-0">
                            <button type="button" onClick={() => removeFromCart(item.id)} className="-m-2 p-2 inline-flex text-gray-400 hover:text-red-500">
                                <Trash2 className="h-5 w-5" />
                            </button>
                            </div>
                        </div>
                        </div>
                    </div>
                    </li>
                ))}
                </ul>
                <div className="bg-white p-6 shadow-sm border border-gray-200">
                    <h2 className="text-lg font-serif font-medium text-gray-900 uppercase tracking-wide mb-6">Customer Details</h2>
                    <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                         <div className="sm:col-span-2">
                            <label className="block text-sm font-medium text-gray-700">Full Name</label>
                            <input type="text" value={guestName} onChange={(e) => setGuestName(e.target.value)} className="mt-1 block w-full bg-white text-gray-900 border border-gray-300 rounded-md shadow-sm p-3" required />
                        </div>
                        <div className="sm:col-span-1">
                            <label className="block text-sm font-medium text-gray-700">Email</label>
                            <input type="email" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} className="mt-1 block w-full bg-white text-gray-900 border border-gray-300 rounded-md shadow-sm p-3" required />
                        </div>
                        <div className="sm:col-span-1">
                            <label className="block text-sm font-medium text-gray-700">Phone</label>
                            <input type="tel" value={guestPhone} onChange={(e) => setGuestPhone(e.target.value)} className="mt-1 block w-full bg-white text-gray-900 border border-gray-300 rounded-md shadow-sm p-3" required />
                        </div>
                        <div className="sm:col-span-2">
                            <label className="block text-sm font-medium text-gray-700">Shipping Address</label>
                            <textarea rows={3} value={guestAddress} onChange={(e) => setGuestAddress(e.target.value)} className="mt-1 block w-full bg-white text-gray-900 border border-gray-300 rounded-md shadow-sm p-3" required />
                        </div>
                    </div>
                </div>
              </section>
              <section className="mt-16 bg-white border border-gray-200 px-4 py-6 sm:p-6 lg:p-8 lg:mt-0 lg:col-span-5 sticky top-28 shadow-sm">
                  <h2 className="text-lg font-serif font-medium text-gray-900 uppercase tracking-wide">Summary</h2>
                  <dl className="mt-6 space-y-4">
                    <div className="flex items-center justify-between">
                        <dt className="text-sm text-gray-600">Subtotal</dt>
                        <dd className="text-sm font-medium text-gray-900">${subtotal.toFixed(2)}</dd>
                    </div>
                    {discountAmount > 0 && (
                      <div className="flex items-center justify-between text-green-600">
                          <dt className="text-sm font-medium">Discount</dt>
                          <dd className="text-sm font-medium">-${discountAmount.toFixed(2)}</dd>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                        <dt className="text-sm text-gray-600">Shipping</dt>
                        <dd className="text-sm font-medium text-gray-900">{currentShippingCost > 0 ? `$${currentShippingCost.toFixed(2)}` : 'Free'}</dd>
                    </div>
                    <div className="border-t border-gray-200 pt-4 flex items-center justify-between">
                        <dt className="text-base font-bold text-gray-900">Total</dt>
                        <dd className="text-xl font-bold text-[#D4AF37]">${finalTotal.toFixed(2)}</dd>
                    </div>
                  </dl>
                  <div className="mt-6">
                  <button type="submit" disabled={isProcessingCheckout} className="w-full bg-[#D4AF37] text-white py-4 uppercase font-bold text-sm tracking-widest hover:bg-black transition-all flex items-center justify-center">
                      {isProcessingCheckout ? <Loader2 className="animate-spin h-5 w-5" /> : 'Place Order (COD)'}
                  </button>
                  </div>
              </section>
            </form>
        )}
      </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-white font-sans text-gray-900">
      <Navbar currentView={currentView} setView={setCurrentView} cartCount={cartCount} isAuthenticated={isAuthenticated} isAdmin={isAdmin} onLogout={handleLogout} siteSettings={settings} />
      <main className="flex-grow">
        {currentView === View.STORE && (
          <StoreFront products={products} banners={banners} onAddToCart={handleAddToCart} onAddReview={handleAddReview} onProductClick={handleProductClick} />
        )}
        {currentView === View.PRODUCT_DETAIL && products.find(p => p.id === selectedProductId) && (
          <ProductDetail product={products.find(p => p.id === selectedProductId)!} onAddToCart={handleAddToCart} onBack={() => setCurrentView(View.STORE)} onAddReview={handleAddReview} />
        )}
        {currentView === View.ADMIN && (
          <AdminDashboard products={products} orders={orders} stats={stats} banners={banners} settings={settings} onAddProduct={handleAddProduct} onUpdateProduct={handleUpdateProduct} onDeleteProduct={handleDeleteProduct} onUpdateOrderStatus={handleUpdateOrderStatus} onAddBanner={handleAddBanner} onDeleteBanner={handleDeleteBanner} onUpdateSettings={handleUpdateSettings} />
        )}
        {currentView === View.LOGIN && <Auth onLogin={handleLogin} />}
        {currentView === View.CART && <CartView />}
        {(currentView === View.ABOUT || currentView === View.PRIVACY || currentView === View.TERMS || currentView === View.SHIPPING) && (
          <InfoPages view={currentView} siteSettings={settings} />
        )}
      </main>
      <footer className="bg-[#1a1a1a] text-white py-12">
        <div className="max-w-4xl mx-auto px-4 flex flex-col items-center">
            <div className="bg-[#333] px-6 py-4 rounded border border-gray-800 mb-8">
                <span className="text-gray-300 font-bold italic text-sm flex items-center gap-2">
                    <Truck className="w-5 h-5" /> CASH ON DELIVERY AVAILABLE
                </span>
            </div>
            <div className="flex flex-wrap justify-center gap-8 mb-8 font-bold tracking-widest text-xs uppercase">
                <button onClick={() => setCurrentView(View.STORE)} className="hover:text-[#D4AF37] transition-colors">HOME</button>
                <button onClick={() => setCurrentView(View.ABOUT)} className="hover:text-[#D4AF37] transition-colors">ABOUT US</button>
                <button onClick={() => window.location.href = `mailto:${settings.contactEmail}`} className="hover:text-[#D4AF37] transition-colors">CONTACT</button>
            </div>
            <p className="text-[10px] text-gray-500 mb-4 tracking-widest uppercase">&copy; {new Date().getFullYear()} {settings.siteName} Fragoma Collection</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
