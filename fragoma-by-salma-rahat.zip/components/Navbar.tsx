
import React, { useState } from 'react';
import { ShoppingCart, Menu, Search, User } from 'lucide-react';
import { View, SiteSettings } from '../types';

interface NavbarProps {
  currentView: View;
  setView: (view: View) => void;
  cartCount: number;
  isAuthenticated: boolean;
  isAdmin: boolean;
  onLogout: () => void;
  siteSettings: SiteSettings;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, setView, cartCount, isAuthenticated, isAdmin, onLogout, siteSettings }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleUserClick = () => {
      setIsMenuOpen(false); // Close menu if open
      if (isAuthenticated) {
          if (isAdmin) {
              // If Admin, toggle navigation or logout
              if (currentView === View.ADMIN) {
                   const shouldLogout = window.confirm("Do you want to logout?");
                   if (shouldLogout) onLogout();
              } else {
                  // If Admin is viewing store, go back to Dashboard
                  setView(View.ADMIN);
              }
          } else {
              // Normal user logout
              const shouldLogout = window.confirm("Do you want to logout?");
              if (shouldLogout) onLogout();
          }
      } else {
          setView(View.LOGIN);
      }
  };

  return (
    <div className="flex flex-col w-full font-sans">
      {/* Top Announcement Bar (Marquee) */}
      {siteSettings.topBarMessage && (
        <div className="bg-black text-[#D4AF37] text-[10px] md:text-xs font-bold tracking-widest py-2 overflow-hidden relative border-b border-[#D4AF37]/30">
           <div className="animate-marquee whitespace-nowrap inline-block px-4">
              {siteSettings.topBarMessage}
           </div>
        </div>
      )}

      {/* Main Header */}
      <nav className="bg-white border-b border-gray-100 py-2 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-24 md:h-48 transition-all duration-300">
            
            {/* Left: Menu Trigger */}
            <div className="flex-shrink-0">
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 border border-gray-200 rounded text-gray-500 hover:bg-gray-50 hover:border-[#D4AF37] transition-colors"
              >
                <Menu className="h-6 w-6" />
              </button>
            </div>

            {/* Center: Brand Logo (Dynamic: Image or SVG) */}
            <div 
              className="flex-1 flex justify-center items-center cursor-pointer group overflow-visible z-10" 
              onClick={() => setView(View.STORE)}
            >
                {siteSettings.logoImage ? (
                    <img 
                        src={siteSettings.logoImage} 
                        alt={siteSettings.siteName} 
                        className="h-20 md:h-56 w-auto object-contain transition-transform duration-300 group-hover:scale-105 drop-shadow-md"
                    />
                ) : (
                    <svg viewBox="0 0 400 300" className="h-20 md:h-56 w-auto transition-transform duration-300 group-hover:scale-105 drop-shadow-xl">
                        <defs>
                            <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="#D4AF37" />
                                <stop offset="30%" stopColor="#FFD700" />
                                <stop offset="70%" stopColor="#B8860B" />
                                <stop offset="100%" stopColor="#D4AF37" />
                            </linearGradient>
                        </defs>
                        {/* Background Card */}
                        <rect x="20" y="20" width="360" height="260" rx="8" fill="#050505" stroke="#111" strokeWidth="1" />
                        
                        {/* Hexagon Border */}
                        <path 
                            d="M200 40 L340 110 L340 200 L200 270 L60 200 L60 110 Z" 
                            fill="none" 
                            stroke="url(#goldGradient)" 
                            strokeWidth="3.5" 
                        />
                        
                        {/* Main Text */}
                        <text 
                            x="200" 
                            y="175" 
                            textAnchor="middle" 
                            fontFamily="'Great Vibes', cursive" 
                            fontSize="110" 
                            fill="url(#goldGradient)"
                            style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}
                        >
                            {siteSettings.siteName || 'Fragoma'}
                        </text>
                        
                        {/* Tagline */}
                        <text 
                            x="200" 
                            y="225" 
                            textAnchor="middle" 
                            fontFamily="sans-serif" 
                            fontSize="14" 
                            fontWeight="bold"
                            letterSpacing="6" 
                            fill="#D4AF37"
                            className="uppercase"
                        >
                            {siteSettings.tagline || 'By Salma Rahat'}
                        </text>

                        {/* Sparkles */}
                        <text x="320" y="130" fontSize="24" fill="#FFD700" className="animate-pulse">✨</text>
                        <text x="80" y="180" fontSize="20" fill="#FFD700" opacity="0.8">✨</text>
                    </svg>
                )}
            </div>

            {/* Right: Search & Cart & User */}
            <div className="flex-shrink-0 flex items-center space-x-2 md:space-x-4">
              <div className="hidden md:flex relative group">
                <input 
                  type="text" 
                  placeholder="Search..." 
                  className="pl-3 pr-10 py-2 bg-white text-gray-900 border border-gray-300 rounded-sm focus:outline-none focus:border-[#D4AF37] w-48 lg:w-64 text-sm transition-all placeholder-gray-500"
                />
                <button className="absolute right-0 top-0 h-full w-10 bg-[#D4AF37] flex items-center justify-center text-white rounded-r-sm hover:bg-black transition-colors">
                  <Search className="h-4 w-4" />
                </button>
              </div>

              <button
                onClick={handleUserClick}
                className="p-2 text-gray-800 hover:text-[#D4AF37] transition-colors relative"
                title={isAuthenticated ? (isAdmin ? "Admin Dashboard / Sign Out" : "Sign Out") : "Sign In"}
              >
                  <User className="h-6 w-6" />
                  {isAuthenticated && <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full"></span>}
              </button>

              <button
                onClick={() => setView(View.CART)}
                className="relative p-2 text-gray-800 hover:text-[#D4AF37] transition-colors"
              >
                <ShoppingCart className="h-7 w-7" />
                {cartCount > 0 && (
                  <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/4 -translate-y-1/4 bg-[#D4AF37] rounded-full">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Menu Dropdown */}
        {isMenuOpen && (
          <div className="absolute top-full left-0 w-full bg-white shadow-lg border-t border-gray-100 p-4 z-40 animate-in slide-in-from-top-2">
             <div className="mb-6 relative flex md:hidden">
                <input 
                  type="text" 
                  placeholder="Search..." 
                  className="pl-3 pr-10 py-3 bg-white text-gray-900 border border-gray-300 rounded-sm focus:outline-none focus:border-[#D4AF37] w-full text-sm placeholder-gray-500"
                />
                <button className="absolute right-0 top-0 h-full w-12 bg-[#D4AF37] flex items-center justify-center text-white rounded-r-sm">
                  <Search className="h-5 w-5" />
                </button>
             </div>
             <ul className="space-y-4 text-gray-800 font-medium tracking-wide text-sm uppercase">
               <li onClick={() => {setView(View.STORE); setIsMenuOpen(false)}} className="py-2 border-b border-gray-100 cursor-pointer hover:text-[#D4AF37] transition-colors">Home</li>
               <li onClick={() => {setView(View.CART); setIsMenuOpen(false)}} className="py-2 border-b border-gray-100 cursor-pointer hover:text-[#D4AF37] transition-colors">My Cart</li>
               
               {/* Admin Link Removed as requested. Access via Login only. */}

               <li onClick={handleUserClick} className="py-2 border-b border-gray-100 cursor-pointer hover:text-[#D4AF37] transition-colors">
                   {isAuthenticated ? 'Sign Out' : 'Sign In / Register'}
               </li>
             </ul>
          </div>
        )}
      </nav>
    </div>
  );
};
