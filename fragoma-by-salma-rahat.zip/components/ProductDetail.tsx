
import React, { useState, useEffect } from 'react';
import { Product, Review } from '../types';
import { ShoppingCart, Star, ArrowLeft, MessageSquare, Truck, ShieldCheck, RefreshCcw, Share2, Check } from 'lucide-react';

interface ProductDetailProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onBack: () => void;
  onAddReview: (productId: string, review: Review) => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({ product, onAddToCart, onBack, onAddReview }) => {
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [reviewerName, setReviewerName] = useState('');
  const [timeLeft, setTimeLeft] = useState<{h: string, m: string, s: string} | null>(null);
  const [isShared, setIsShared] = useState(false);

  const hasDiscount = product.discount && product.discount > 0;
  const finalPrice = hasDiscount ? product.price * (1 - product.discount! / 100) : product.price;

  useEffect(() => {
    if (!product.saleEndTime) return;
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const end = new Date(product.saleEndTime!).getTime();
      const distance = end - now;
      if (distance < 0) { clearInterval(interval); setTimeLeft(null); return; }
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)).toString().padStart(2, '0');
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)).toString().padStart(2, '0');
      const seconds = Math.floor((distance % (1000 * 60)) / 1000).toString().padStart(2, '0');
      setTimeLeft({ h: hours, m: minutes, s: seconds });
    }, 1000);
    return () => clearInterval(interval);
  }, [product.saleEndTime]);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment || !reviewerName) return;
    const review: Review = { id: Date.now().toString(), userName: reviewerName, rating: newRating, comment: newComment, date: new Date().toISOString() };
    onAddReview(product.id, review);
    setNewComment(''); setReviewerName(''); setNewRating(5);
  };

  const handleShare = () => {
    const productUrl = `${window.location.origin}${window.location.pathname}?product=${product.id}`;
    const message = `🌟 *FRAGOMA PREMIUM COLLECTION* 🌟\n\n🛍️ *Product:* ${product.name}\n💰 *Price:* $${finalPrice.toFixed(2)}\n🌿 *Collection:* Pure Natural Essence\n\nOrder now for Cash on Delivery! 🚚\n\n🔗 *Full Details:* ${productUrl}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    setIsShared(true);
    setTimeout(() => setIsShared(false), 2000);
  };

  const averageRating = product.reviews && product.reviews.length > 0
    ? product.reviews.reduce((acc, r) => acc + r.rating, 0) / product.reviews.length
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-20 animate-in fade-in duration-500">
      <div className="mb-8">
        <button onClick={onBack} className="flex items-center text-sm font-bold text-gray-500 hover:text-black uppercase tracking-widest transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Collection
        </button>
      </div>

      <div className="lg:grid lg:grid-cols-2 lg:gap-x-12 xl:gap-x-16">
        <div className="relative aspect-[3/4] overflow-hidden bg-white border border-gray-100 shadow-sm">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>

        <div className="mt-10 lg:mt-0 flex flex-col">
          {/* FLASH SALE TIMER UI */}
          {timeLeft && (
            <div className="w-full mb-8 overflow-hidden rounded-xl shadow-2xl bg-[#2a2a2a] border border-gray-800">
              <div className="bg-[#e62e2e] py-2 px-4 flex items-center justify-between text-white font-bold tracking-widest text-[10px] sm:text-xs">
                <div className="flex items-center gap-1">
                   <span>🔥 FLASH SALE!</span>
                   <span className="hidden sm:inline">| LIMITED TIME OFFER!</span>
                </div>
                <div className="animate-pulse uppercase">While Supplies Last</div>
              </div>
              <div className="py-6 px-4 flex flex-col items-center">
                <p className="text-gray-300 italic font-serif text-sm mb-4">Hurry! Sale Ends In:</p>
                <div className="flex items-center gap-4 sm:gap-6">
                  <div className="flex flex-col items-center">
                    <div className="bg-[#1a1a1a] text-white text-3xl sm:text-5xl font-mono px-3 py-4 rounded-lg border border-gray-700 shadow-inner">{timeLeft.h}</div>
                    <span className="text-[10px] text-gray-500 uppercase mt-2 font-bold tracking-widest">Hours</span>
                  </div>
                  <span className="text-3xl text-gray-500 font-bold mb-6">:</span>
                  <div className="flex flex-col items-center">
                    <div className="bg-[#1a1a1a] text-white text-3xl sm:text-5xl font-mono px-3 py-4 rounded-lg border border-gray-700 shadow-inner">{timeLeft.m}</div>
                    <span className="text-[10px] text-gray-500 uppercase mt-2 font-bold tracking-widest">Mins</span>
                  </div>
                  <span className="text-3xl text-gray-500 font-bold mb-6">:</span>
                  <div className="flex flex-col items-center">
                    <div className="bg-[#1a1a1a] text-white text-3xl sm:text-5xl font-mono px-3 py-4 rounded-lg border border-gray-700 shadow-inner">{timeLeft.s}</div>
                    <span className="text-[10px] text-gray-500 uppercase mt-2 font-bold tracking-widest">Secs</span>
                  </div>
                </div>
                <p className="mt-4 text-[#D4AF37] font-bold text-xs tracking-widest uppercase animate-bounce">Don't Miss Out - Order Now!</p>
              </div>
            </div>
          )}

          <div className="border-b border-gray-200 pb-6">
            <h1 className="text-3xl md:text-5xl font-serif text-gray-900 tracking-tight leading-none mb-4 uppercase">{product.name}</h1>
            <div className="flex items-baseline space-x-3">
              <p className={`text-2xl md:text-3xl font-bold ${hasDiscount ? 'text-red-600' : 'text-gray-900'}`}>${finalPrice.toFixed(2)}</p>
              {hasDiscount && <p className="text-lg text-gray-400 line-through">${product.price.toFixed(2)}</p>}
            </div>
          </div>

          <div className="py-6 space-y-4">
            <p className="text-gray-600 leading-relaxed text-sm mb-6">{product.description}</p>
            
            {/* Action Buttons Section - Shopify Inspired */}
            <div className="space-y-3">
                <button onClick={() => onAddToCart(product)} className="w-full bg-black text-white py-4 px-8 uppercase font-bold tracking-[0.2em] text-sm hover:bg-[#D4AF37] transition-all flex items-center justify-center space-x-3 shadow-xl">
                  <ShoppingCart className="h-5 w-5" /> 
                  <span>Add to Shopping Cart</span>
                </button>
                
                {/* Shopify-style Share Button */}
                <button 
                  onClick={handleShare}
                  className="w-full flex items-center justify-center gap-3 py-3 border border-gray-200 hover:border-[#25D366] transition-all group bg-white"
                >
                  <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center text-[#25D366] group-hover:bg-[#25D366] group-hover:text-white transition-colors">
                    {isShared ? <Check className="h-4 w-4" /> : <Share2 className="h-4 w-4" />}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-500 group-hover:text-[#25D366]">
                    {isShared ? 'Link Copied to WhatsApp' : 'Share this via WhatsApp'}
                  </span>
                </button>
            </div>
          </div>
          
          <div className="mt-auto grid grid-cols-1 sm:grid-cols-3 gap-6 pt-10 border-t border-gray-100">
             <div className="flex flex-col items-center text-center">
                <Truck className="h-6 w-6 text-[#D4AF37] mb-2" />
                <span className="text-[9px] font-bold uppercase tracking-widest text-gray-500">Fast Delivery</span>
             </div>
             <div className="flex flex-col items-center text-center">
                <ShieldCheck className="h-6 w-6 text-[#D4AF37] mb-2" />
                <span className="text-[9px] font-bold uppercase tracking-widest text-gray-500">Premium Quality</span>
             </div>
             <div className="flex flex-col items-center text-center">
                <RefreshCcw className="h-6 w-6 text-[#D4AF37] mb-2" />
                <span className="text-[9px] font-bold uppercase tracking-widest text-gray-500">Secure Payment</span>
             </div>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="mt-20">
          <h2 className="text-2xl font-serif text-gray-900 mb-8 uppercase tracking-widest border-b pb-4 flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-[#D4AF37]" /> Customer Reviews
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div className="space-y-6">
                  {product.reviews && product.reviews.length > 0 ? (
                      product.reviews.map((rev) => (
                          <div key={rev.id} className="bg-gray-50 p-6 rounded-none border border-gray-100">
                              <div className="flex justify-between items-start mb-2">
                                  <div>
                                      <p className="font-bold text-gray-900 uppercase tracking-widest text-xs">{rev.userName}</p>
                                      <div className="flex space-x-1 mt-1">
                                          {[1, 2, 3, 4, 5].map((s) => (
                                              <Star key={s} className={`h-3 w-3 ${s <= rev.rating ? 'text-[#D4AF37] fill-[#D4AF37]' : 'text-gray-300'}`} />
                                          ))}
                                      </div>
                                  </div>
                                  <span className="text-[10px] text-gray-400 font-bold uppercase">{new Date(rev.date).toLocaleDateString()}</span>
                              </div>
                              <p className="text-gray-600 text-sm italic mt-4">"{rev.comment}"</p>
                          </div>
                      ))
                  ) : (
                      <p className="text-gray-500 font-serif italic">No reviews yet. Be the first to share your experience!</p>
                  )}
              </div>
              <div>
                  <form onSubmit={handleReviewSubmit} className="bg-white p-8 border border-gray-200 shadow-sm sticky top-24">
                      <h4 className="text-sm font-bold text-gray-900 mb-6 uppercase tracking-widest">Write a Review</h4>
                      <div className="space-y-4">
                          <div className="flex space-x-2 mb-4">
                              {[1, 2, 3, 4, 5].map((star) => (
                                  <button key={star} type="button" onClick={() => setNewRating(star)} className="focus:outline-none">
                                      <Star className={`h-6 w-6 ${star <= newRating ? 'text-[#D4AF37] fill-[#D4AF37]' : 'text-gray-300'}`} />
                                  </button>
                              ))}
                          </div>
                          <input type="text" value={reviewerName} onChange={(e) => setReviewerName(e.target.value)} placeholder="Full Name" className="w-full p-4 border border-gray-300 outline-none text-sm" required />
                          <textarea value={newComment} onChange={(e) => setNewComment(e.target.value)} rows={4} placeholder="Your thoughts..." className="w-full p-4 border border-gray-300 outline-none text-sm" required />
                          <button type="submit" className="w-full bg-black text-white py-4 uppercase text-xs font-bold tracking-widest hover:bg-[#D4AF37] transition-colors">Submit Review</button>
                      </div>
                  </form>
              </div>
          </div>
      </div>
    </div>
  );
};
