
import React from 'react';
import { View, SiteSettings } from '../types';

interface InfoPagesProps {
  view: View;
  siteSettings: SiteSettings;
}

export const InfoPages: React.FC<InfoPagesProps> = ({ view, siteSettings }) => {
  const renderContent = () => {
    switch (view) {
      case View.ABOUT:
        return (
          <div className="space-y-6 text-gray-700 leading-relaxed text-sm md:text-base">
            <p className="text-base md:text-lg font-medium">
              At <span className="text-[#D4AF37] font-bold">{siteSettings.siteName} {siteSettings.tagline}</span>, we provide high-quality essential oils and wellness products to customers across Canada. Our mission is to enhance your daily lifestyle through natural and healthy solutions.
            </p>
            <ul className="list-disc pl-5 space-y-2">
              <li>We offer only pure and authentic oils.</li>
              <li>Every product is carefully selected and tested.</li>
              <li>Customer satisfaction is our top priority.</li>
            </ul>
            <p>
              Our website provides a secure, convenient, and reliable online shopping experience with home delivery anywhere in Canada.
            </p>
          </div>
        );

      case View.PRIVACY:
        return (
          <div className="space-y-6 md:space-y-8 text-gray-700 leading-relaxed text-sm md:text-base">
            <p className="italic text-xs md:text-sm text-gray-500">Last Updated: {new Date().toLocaleDateString()}</p>
            <p>{siteSettings.siteName} respects your privacy and complies with Canadian privacy laws (PIPEDA).</p>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">Information We Collect</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Personal information like name, email, phone number, and shipping address when you place an order.</li>
                <li>Website usage data through cookies and analytics to improve your experience.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">How We Use Your Information</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>To process and deliver orders.</li>
                <li>To communicate promotions, offers, and updates (if you opt-in).</li>
                <li>To improve our website and services.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">Information Protection</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>All collected information is stored securely.</li>
                <li>We do not share your personal information with third parties without your consent, except where required by law.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">Your Rights</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>You have the right to access, correct, or delete your personal information.</li>
                <li>You may withdraw consent at any time for marketing communications.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">Cookies and Tracking</h3>
              <p>Our website uses cookies to improve your browsing experience. You can disable cookies in your browser if you choose.</p>
            </section>

            <section className="bg-gray-50 p-4 rounded border border-gray-100">
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">Contact Us</h3>
              <p>For privacy-related inquiries, please contact:</p>
              <p className="mt-2 text-sm break-all"><strong>Email:</strong> {siteSettings.contactEmail}</p>
              <p className="text-sm"><strong>Phone:</strong> {siteSettings.contactPhone}</p>
            </section>
          </div>
        );

      case View.TERMS:
        return (
          <div className="space-y-6 md:space-y-8 text-gray-700 leading-relaxed text-sm md:text-base">
             <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">1. General</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>By using {siteSettings.siteName}’s website, you agree to these terms.</li>
                <li>Website content is for informational and commercial purposes only.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">2. Orders & Payments</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Product availability and prices may change without notice.</li>
                <li>Payments are processed securely via online gateways.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">3. Shipping & Delivery</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Delivery times vary depending on product and location in Canada.</li>
                <li>While we strive to deliver on time, {siteSettings.siteName} is not responsible for shipping delays.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">4. Returns & Refunds</h3>
              <ul className="list-disc pl-5 space-y-1">
                 <li>If a product is damaged, defective, or incorrect, claims must be made within 7 days of delivery.</li>
                 <li>Refunds are issued to the original payment method.</li>
              </ul>
            </section>

             <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">5. Limitation of Liability</h3>
              <p>{siteSettings.siteName} is not liable for any direct or indirect damages resulting from the use of products or the website.</p>
            </section>

             <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">6. Changes to Terms</h3>
              <p>We may update these terms at any time. Updates will be published on the website.</p>
            </section>

             <section>
              <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">7. Compliance</h3>
              <p>Our website follows Canadian e-commerce and consumer protection laws.</p>
            </section>
          </div>
        );

      case View.SHIPPING:
        return (
          <div className="space-y-6 md:space-y-8 text-gray-700 leading-relaxed text-sm md:text-base">
            <p className="text-base md:text-lg font-medium">{siteSettings.siteName} delivers across Canada. We aim to make your online shopping experience smooth and reliable.</p>

            {/* Shipping Policy Section */}
            <div>
              <h2 className="text-xl md:text-2xl font-serif font-bold text-[#D4AF37] mb-4 border-b pb-2">Shipping Policy</h2>
              
              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">1. Shipping Methods</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Standard shipping is available for all Canadian provinces.</li>
                  <li>Expedited shipping options may be available at checkout.</li>
                </ul>
              </section>

              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">2. Shipping Time</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Standard orders typically take 3–7 business days to arrive.</li>
                  <li>Delivery times may vary based on location, product availability, and postal service conditions.</li>
                </ul>
              </section>

              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">3. Shipping Costs</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Shipping fees are calculated at checkout based on order weight and destination.</li>
                  <li>Occasionally, we offer free shipping promotions for certain orders.</li>
                </ul>
              </section>

              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">4. Tracking</h3>
                <p>Once your order is shipped, you will receive a tracking number via email to monitor your delivery.</p>
              </section>

              <section>
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">5. Shipping Issues</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>{siteSettings.siteName} is not responsible for delays caused by postal services, weather, or customs.</li>
                  <li>Please ensure your shipping address is correct. {siteSettings.siteName} is not responsible for lost shipments due to incorrect addresses.</li>
                </ul>
              </section>
            </div>

            {/* Returns Policy Section */}
            <div className="pt-8 mt-8 border-t border-gray-100">
              <h2 className="text-xl md:text-2xl font-serif font-bold text-[#D4AF37] mb-4 border-b pb-2">Returns & Refunds Policy</h2>

              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">1. Eligibility for Returns</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Products must be damaged, defective, or incorrect.</li>
                  <li>Claims must be made within 7 days of receiving the order.</li>
                  <li>Products must be in their original packaging.</li>
                </ul>
              </section>

              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">2. Non-Returnable Items</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Opened or used essential oils (for hygiene reasons).</li>
                  <li>Items purchased on sale or special promotions (unless defective).</li>
                </ul>
              </section>

              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">3. How to Return</h3>
                <p>Contact our customer service with your order number and reason for return. We will provide instructions for returning the product.</p>
              </section>

              <section className="mb-6">
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">4. Refunds</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Refunds will be issued to the original payment method after we receive and inspect the returned product.</li>
                  <li>Shipping costs are non-refundable, unless the product was defective or incorrectly sent.</li>
                </ul>
              </section>

              <section>
                <h3 className="text-base md:text-lg font-serif font-bold text-gray-900 mb-2">5. Exchanges</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Defective or incorrect products can be exchanged for the correct item.</li>
                  <li>Contact customer service for the exchange process.</li>
                </ul>
              </section>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const getTitle = () => {
    switch (view) {
      case View.ABOUT: return "About Us";
      case View.PRIVACY: return "Privacy Policy";
      case View.TERMS: return "Terms & Conditions";
      case View.SHIPPING: return "Shipping & Returns";
      default: return "";
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-10 md:py-16 px-4 sm:px-6 lg:px-8 min-h-screen bg-white">
      <div className="text-center mb-8 md:mb-12">
        <h1 className="text-2xl md:text-4xl font-serif text-[#D4AF37] mb-3 md:mb-4">{getTitle()}</h1>
        <div className="w-16 md:w-24 h-0.5 bg-gray-200 mx-auto"></div>
      </div>
      <div className="prose prose-stone max-w-none">
        {renderContent()}
      </div>
    </div>
  );
};
