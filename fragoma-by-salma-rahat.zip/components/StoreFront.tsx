
import React, { useState, useEffect } from 'react';
import { Product, Banner, Review } from '../types';
import { ProductCard } from './ProductCard';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface StoreFrontProps {
  products: Product[];
  banners: Banner[];
  onAddToCart: (product: Product) => void;
  onAddReview: (productId: string, review: Review) => void;
  onProductClick: (product: Product) => void;
}

export const StoreFront: React.FC<StoreFrontProps> = ({ products, banners, onAddToCart, onAddReview, onProductClick }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [banners.length]);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % banners.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + banners.length) % banners.length);

  const featuredProducts = products.filter(p => p.featured);
  const regularProducts = products.filter(p => !p.featured);

  return (
    <div className="bg-white min-h-screen pb-20">
      <div className="relative h-[60vh] md:h-[600px] w-full bg-black overflow-hidden group">
        {banners.map((banner, index) => (
          <div key={banner.id} className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}>
            <div className="absolute inset-0 bg-black/40 z-10"></div>
            <img src={banner.image} alt={banner.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 z-20 flex flex-col justify-center items-center text-center p-6 sm:p-12">
               <span className="text-[#D4AF37] font-script text-3xl md:text-5xl mb-3 drop-shadow-md">Fragoma Collection</span>
               <h2 className="text-4xl md:text-7xl font-serif text-white tracking-tight leading-none mb-6 uppercase max-w-4xl">{banner.title}</h2>
               <p className="text-gray-200 uppercase tracking-[0.2em] text-xs md:text-sm max-w-lg mb-8 hidden sm:block">{banner.subtitle}</p>
               <button className="px-8 py-3 bg-[#D4AF37] text-white text-xs font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-colors shadow-lg">Shop Now</button>
            </div>
          </div>
        ))}
        {banners.length > 1 && (
          <>
            <button onClick={prevSlide} className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-2 text-white/50 hover:text-white opacity-0 group-hover:opacity-100 transition-all"><ChevronLeft className="h-8 w-8" /></button>
            <button onClick={nextSlide} className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-2 text-white/50 hover:text-white opacity-0 group-hover:opacity-100 transition-all"><ChevronRight className="h-8 w-8" /></button>
          </>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="text-center mb-12 md:mb-16">
           <span className="text-[#D4AF37] font-script text-2xl md:text-3xl">Curated Selection</span>
           <h2 className="text-2xl md:text-4xl font-serif text-gray-900 mt-2 mb-4">OUR COLLECTION</h2>
           <div className="w-16 md:w-24 h-0.5 bg-[#D4AF37] mx-auto"></div>
        </div>

        {featuredProducts.length > 0 && (
          <div className="mb-16">
             <div className="flex items-center space-x-2 mb-6 text-[#D4AF37]">
                <Star className="h-5 w-5 fill-current" />
                <h3 className="text-sm font-bold uppercase tracking-widest text-black">Featured</h3>
             </div>
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
                {featuredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} onAddReview={onAddReview} onProductClick={onProductClick} />
                ))}
             </div>
          </div>
        )}

        {regularProducts.length > 0 && (
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {regularProducts.map((product) => (
                  <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} onAddReview={onAddReview} onProductClick={onProductClick} />
              ))}
           </div>
        )}
      </div>
    </div>
  );
};