
import React, { useState, useEffect } from 'react';
import { ShoppingCart, Star, MessageSquare, X, Eye, Share2, Clock, Check } from 'lucide-react';
import { Product, Review } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onAddReview: (productId: string, review: Review) => void;
  onProductClick: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onAddReview, onProductClick }) => {
  const [showReviews, setShowReviews] = useState(false);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [reviewerName, setReviewerName] = useState('');
  const [isShared, setIsShared] = useState(false);
  const [timeLeft, setTimeLeft] = useState<string | null>(null);
  const [saleExpired, setSaleExpired] = useState(false);

  const hasDiscount = product.discount && product.discount > 0;
  const finalPrice = hasDiscount ? product.price * (1 - product.discount! / 100) : product.price;

  useEffect(() => {
    if (!product.saleEndTime || !hasDiscount) return;
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const end = new Date(product.saleEndTime!).getTime();
      const distance = end - now;
      if (distance < 0) {
        clearInterval(timer);
        setTimeLeft(null);
        setSaleExpired(true);
        return;
      }
      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);
      setTimeLeft(`${days > 0 ? days + 'd ' : ''}${hours}h ${minutes}m ${seconds}s`);
    }, 1000);
    return () => clearInterval(timer);
  }, [product.saleEndTime, hasDiscount]);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment || !reviewerName) return;
    const review: Review = {
      id: Date.now().toString(),
      userName: reviewerName,
      rating: newRating,
      comment: newComment,
      date: new Date().toISOString()
    };
    onAddReview(product.id, review);
    setNewComment('');
    setReviewerName('');
    setNewRating(5);
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    const productUrl = `${window.location.origin}${window.location.pathname}?product=${product.id}`;
    const message = `✨ *FRAGOMA EXCLUSIVE* ✨\n\n🛍️ *Product:* ${product.name}\n💰 *Price:* $${finalPrice.toFixed(2)}\n🌿 *Collection:* Pure Natural Essence\n\nOrder now for Cash on Delivery! 🚚\n\n🔗 *Shop Here:* ${productUrl}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    setIsShared(true);
    setTimeout(() => setIsShared(false), 2000);
  };

  const averageRating = product.reviews && product.reviews.length > 0
    ? product.reviews.reduce((acc, r) => acc + r.rating, 0) / product.reviews.length
    : 0;

  return (
    <div className="group relative bg-[#FDFBF7] flex flex-col overflow-hidden transition-all duration-300 hover:shadow-xl border border-gray-100 h-full">
      {/* Image Container */}
      <div className="relative aspect-[3/4] bg-gray-100 overflow-hidden cursor-pointer" onClick={() => onProductClick(product)}>
        <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
        
        <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
            {product.featured && <div className="bg-black text-[#D4AF37] text-[9px] uppercase font-bold px-2 py-1 border border-[#D4AF37]/50 shadow-sm">Featured</div>}
            {hasDiscount && !saleExpired && <div className="bg-red-600 text-white text-[9px] uppercase font-bold px-2 py-1 shadow-sm">-{product.discount}% Sale</div>}
            {saleExpired && <div className="bg-gray-500 text-white text-[9px] uppercase font-bold px-2 py-1 shadow-sm">Sale Ended</div>}
        </div>

        {/* Countdown Timer Overlay */}
        {timeLeft && (
          <div className="absolute top-4 right-4 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="bg-black/70 backdrop-blur-md text-white px-3 py-1.5 rounded-full flex items-center space-x-2 text-[10px] font-bold uppercase tracking-widest border border-white/20">
              <Clock className="h-3 w-3 text-[#D4AF37]" />
              <span>{timeLeft}</span>
            </div>
          </div>
        )}

        {/* Hover View Detail Overlay */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
            <div className="bg-white/90 backdrop-blur-sm p-3 rounded-full shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                <Eye className="h-6 w-6 text-black" />
            </div>
        </div>

        {/* Action Buttons Overlay - Shopify Style */}
        <div className="absolute inset-x-0 bottom-0 p-3 md:p-4 translate-y-0 md:translate-y-full md:group-hover:translate-y-0 transition-transform duration-300 bg-white/95 backdrop-blur-sm border-t border-[#D4AF37]/20 z-10 space-y-2">
             <button 
               onClick={(e) => { e.stopPropagation(); onAddToCart(product); }} 
               className="w-full flex items-center justify-center space-x-2 bg-black text-white py-2.5 uppercase text-[10px] font-bold tracking-widest hover:bg-[#D4AF37] transition-colors shadow-lg active:scale-95"
             >
              <ShoppingCart className="h-3 w-3" />
              <span>Add to Cart</span>
            </button>
            
            <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={(e) => { e.stopPropagation(); setShowReviews(true); }} 
                  className="flex items-center justify-center space-x-1 bg-white text-black border border-gray-200 py-2.5 uppercase text-[9px] font-bold tracking-widest hover:bg-gray-50 transition-colors"
                >
                  <MessageSquare className="h-3 w-3 text-gray-400" />
                  <span>Reviews ({product.reviews?.length || 0})</span>
                </button>
                <button 
                  onClick={handleShare}
                  className={`flex items-center justify-center space-x-1 py-2.5 uppercase text-[9px] font-bold tracking-widest transition-all border ${isShared ? 'bg-green-500 text-white border-green-500' : 'bg-white text-[#25D366] border-green-100 hover:border-[#25D366]'}`}
                >
                  {isShared ? <Check className="h-3 w-3" /> : <Share2 className="h-3 w-3" />}
                  <span>{isShared ? 'Shared' : 'WhatsApp'}</span>
                </button>
            </div>
        </div>
      </div>

      {/* Details */}
      <div className="p-4 md:p-6 text-center flex flex-col items-center flex-1 cursor-pointer" onClick={() => onProductClick(product)}>
        <h3 className="text-base md:text-xl font-serif text-gray-900 mb-1 leading-tight group-hover:text-[#D4AF37] transition-colors line-clamp-2 uppercase">{product.name}</h3>
        <div className="flex items-center space-x-1 mb-2">
            {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className={`h-3 w-3 ${s <= Math.round(averageRating) ? 'text-[#D4AF37] fill-[#D4AF37]' : 'text-gray-300'}`} />
            ))}
            <span className="text-[10px] text-gray-500">({product.reviews?.length || 0})</span>
        </div>
        <p className="text-[9px] uppercase tracking-[0.2em] text-gray-400 mb-4 font-medium">Fragoma Collection</p>
        <div className="mt-auto flex items-center justify-center flex-col">
            <div className="flex items-center justify-center space-x-2">
                {hasDiscount && !saleExpired && <span className="text-xs text-gray-400 line-through">${product.price.toFixed(2)}</span>}
                <span className={`text-base font-medium ${hasDiscount && !saleExpired ? 'text-red-600' : 'text-gray-900'}`}>
                  ${(hasDiscount && !saleExpired ? finalPrice : product.price).toFixed(2)}
                </span>
            </div>
            {timeLeft && (
              <p className="text-[9px] text-[#D4AF37] font-bold mt-1 uppercase tracking-tighter flex items-center">
                <Clock className="h-2.5 w-2.5 mr-1" /> Ends: {timeLeft}
              </p>
            )}
        </div>
      </div>

      {/* Reviews Modal */}
      {showReviews && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm" onClick={(e) => e.stopPropagation()}>
           <div className="bg-white w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-none shadow-2xl p-6 relative">
              <button onClick={() => setShowReviews(false)} className="absolute top-4 right-4 p-1 rounded-full hover:bg-gray-100"><X className="h-5 w-5" /></button>
              <h2 className="text-2xl font-serif text-gray-900 mb-6 border-b pb-2 uppercase tracking-wide">Customer Reviews</h2>
              <form onSubmit={handleReviewSubmit} className="mb-8 bg-gray-50 p-4 rounded-none border border-gray-100">
                  <h4 className="text-sm font-bold text-gray-800 mb-4 uppercase tracking-widest">Write a Review</h4>
                  <div className="space-y-4">
                      <div className="flex space-x-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                              <button key={star} type="button" onClick={() => setNewRating(star)} className="focus:outline-none">
                                  <Star className={`h-6 w-6 ${star <= newRating ? 'text-[#D4AF37] fill-[#D4AF37]' : 'text-gray-300'}`} />
                              </button>
                          ))}
                      </div>
                      <input type="text" value={reviewerName} onChange={(e) => setReviewerName(e.target.value)} placeholder="Your Name" className="w-full p-3 text-sm border border-gray-300 rounded-none outline-none bg-white text-gray-900" required />
                      <textarea value={newComment} onChange={(e) => setNewComment(e.target.value)} rows={3} placeholder="Write your thoughts..." className="w-full p-3 text-sm border border-gray-300 rounded-none outline-none bg-white text-gray-900" required />
                      <button type="submit" className="w-full bg-[#D4AF37] text-white py-3 rounded-none text-sm font-bold uppercase tracking-widest hover:bg-black transition-colors">Post Review</button>
                  </div>
              </form>
              <div className="space-y-6">
                  {product.reviews && product.reviews.length > 0 ? (
                      product.reviews.map((rev) => (
                          <div key={rev.id} className="border-b border-gray-100 pb-4">
                              <div className="flex justify-between items-start mb-2">
                                  <div>
                                      <p className="font-bold text-gray-900 text-xs uppercase tracking-widest">{rev.userName}</p>
                                      <div className="flex space-x-1 mt-1">
                                          {[1, 2, 3, 4, 5].map((s) => (
                                              <Star key={s} className={`h-3 w-3 ${s <= rev.rating ? 'text-[#D4AF37] fill-[#D4AF37]' : 'text-gray-300'}`} />
                                          ))}
                                      </div>
                                  </div>
                                  <span className="text-[10px] text-gray-400 font-bold uppercase">{new Date(rev.date).toLocaleDateString()}</span>
                              </div>
                              <p className="text-gray-600 text-sm italic">"{rev.comment}"</p>
                          </div>
                      ))
                  ) : (
                      <p className="text-center text-gray-500 font-serif italic">No reviews yet. Be the first!</p>
                  )}
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
