
import React, { useState, useEffect } from 'react';
import { 
  Plus, Sparkles, Upload, Loader2, DollarSign, Tag, Type, Star, 
  LayoutGrid, ShoppingBag, Package, BarChart3, Users, Eye, TrendingUp, Trash2, Search, ArrowLeft, Globe, Palette, Image as ImageIcon, Settings, Clock, Truck, Megaphone, ShoppingCart, Save
} from 'lucide-react';
import { Product, CATEGORIES, Order, DashboardStats, OrderStatus, Banner, SiteSettings } from '../types';
import { generateProductDescription } from '../services/geminiService';

interface AdminDashboardProps {
  products: Product[];
  orders: Order[];
  stats: DashboardStats;
  banners: Banner[];
  settings: SiteSettings;
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  onAddBanner: (banner: Banner) => void;
  onDeleteBanner: (id: string) => void;
  onUpdateSettings: (settings: SiteSettings) => void;
}

type AdminTab = 'OVERVIEW' | 'ORDERS' | 'PRODUCTS' | 'DESIGN' | 'SETTINGS';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  products, 
  orders, 
  stats, 
  banners,
  settings,
  onAddProduct, 
  onUpdateProduct,
  onDeleteProduct,
  onUpdateOrderStatus,
  onAddBanner,
  onDeleteBanner,
  onUpdateSettings
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('OVERVIEW');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // --- Product Form State (Restored) ---
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('10');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [description, setDescription] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [keywords, setKeywords] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  const [discount, setDiscount] = useState('');
  const [saleEndTime, setSaleEndTime] = useState('');

  // SEO State
  const [seoTitle, setSeoTitle] = useState('');
  const [seoMetaDesc, setSeoMetaDesc] = useState('');
  const [seoKeywords, setSeoKeywords] = useState('');

  // --- Banner Form State ---
  const [bannerTitle, setBannerTitle] = useState('');
  const [bannerSubtitle, setBannerSubtitle] = useState('');
  const [bannerImage, setBannerImage] = useState<string | null>(null);

  // --- Settings State ---
  const [siteName, setSiteName] = useState(settings.siteName);
  const [tagline, setTagline] = useState(settings.tagline);
  const [contactEmail, setContactEmail] = useState(settings.contactEmail);
  const [contactPhone, setContactPhone] = useState(settings.contactPhone);
  const [instagramUrl, setInstagramUrl] = useState(settings.instagramUrl);
  const [footerDescription, setFooterDescription] = useState(settings.footerDescription);
  const [logoImage, setLogoImage] = useState<string | null>(settings.logoImage);
  const [shippingCost, setShippingCost] = useState(settings.shippingCost.toString());
  const [freeShippingThreshold, setFreeShippingThreshold] = useState(settings.freeShippingThreshold.toString());
  const [topBarMessage, setTopBarMessage] = useState(settings.topBarMessage || '');

  // Update local state when settings prop changes (e.g. on load)
  useEffect(() => {
    setSiteName(settings.siteName);
    setTagline(settings.tagline);
    setContactEmail(settings.contactEmail);
    setContactPhone(settings.contactPhone);
    setInstagramUrl(settings.instagramUrl);
    setFooterDescription(settings.footerDescription);
    setLogoImage(settings.logoImage);
    setShippingCost(settings.shippingCost.toString());
    setFreeShippingThreshold(settings.freeShippingThreshold.toString());
    setTopBarMessage(settings.topBarMessage || '');
  }, [settings]);

  // --- Image Handlers ---
  const handleProductImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleBannerImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setBannerImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setLogoImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  // --- Business Logic ---
  const handleGenerateDescription = async () => {
    if (!name || !keywords) {
      alert("Please enter a product name and some keywords first.");
      return;
    }
    setIsGenerating(true);
    const desc = await generateProductDescription(name, category, keywords);
    setDescription(desc);
    setIsGenerating(false);
  };

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !price || !description || !image) {
        alert("Please fill all required fields");
        return;
    }
    const newProduct: Product = {
      id: Date.now().toString(),
      name,
      price: parseFloat(price),
      stock: parseInt(stock),
      category,
      description,
      image,
      featured: isFeatured,
      discount: discount ? parseFloat(discount) : undefined,
      saleEndTime: saleEndTime || undefined,
      seoTitle,
      metaDescription: seoMetaDesc,
      seoKeywords,
      reviews: []
    };
    onAddProduct(newProduct);
    setName(''); setPrice(''); setStock('10'); setKeywords(''); setDescription(''); setImage(null); setIsFeatured(false); setDiscount(''); setSaleEndTime(''); setSeoTitle(''); setSeoMetaDesc(''); setSeoKeywords('');
    alert("Product added successfully!");
  };

  const handleAddBannerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bannerTitle || !bannerImage) { alert("Please provide a title and image."); return; }
    onAddBanner({ id: Date.now().toString(), title: bannerTitle, subtitle: bannerSubtitle, image: bannerImage });
    setBannerTitle(''); setBannerSubtitle(''); setBannerImage(null);
    alert("Banner added successfully!");
  };

  const handleSettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({ 
      siteName, 
      tagline, 
      contactEmail, 
      contactPhone, 
      instagramUrl, 
      footerDescription, 
      logoImage, 
      shippingCost: parseFloat(shippingCost) || 0, 
      freeShippingThreshold: parseFloat(freeShippingThreshold) || 0, 
      topBarMessage 
    });
    alert("Site settings updated successfully!");
  };

  const handleStockChange = (product: Product, newStock: string) => {
    const parsed = parseInt(newStock);
    if (!isNaN(parsed) && parsed >= 0) { onUpdateProduct({ ...product, stock: parsed }); }
  };

  // --- Renderers ---
  const renderOverview = () => (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        <div className="bg-white p-5 shadow rounded-lg border border-gray-100">
          <div className="flex items-center">
            <div className="bg-green-100 p-3 rounded-md"><DollarSign className="h-6 w-6 text-green-600" /></div>
            <div className="ml-5"><dt className="text-xs font-medium text-gray-500 uppercase tracking-wider">Total Sales</dt><dd className="text-lg font-bold text-gray-900">${stats.totalSales.toFixed(2)}</dd></div>
          </div>
        </div>
        <div className="bg-white p-5 shadow rounded-lg border border-gray-100">
          <div className="flex items-center">
            <div className="bg-blue-100 p-3 rounded-md"><Package className="h-6 w-6 text-blue-600" /></div>
            <div className="ml-5"><dt className="text-xs font-medium text-gray-500 uppercase tracking-wider">Orders</dt><dd className="text-lg font-bold text-gray-900">{stats.totalOrders}</dd></div>
          </div>
        </div>
        <div className="bg-white p-5 shadow rounded-lg border border-gray-100">
          <div className="flex items-center">
            <div className="bg-purple-100 p-3 rounded-md"><Users className="h-6 w-6 text-purple-600" /></div>
            <div className="ml-5"><dt className="text-xs font-medium text-gray-500 uppercase tracking-wider">Visitors</dt><dd className="text-lg font-bold text-gray-900">{stats.uniqueVisitors}</dd></div>
          </div>
        </div>
        <div className="bg-white p-5 shadow rounded-lg border border-gray-100">
          <div className="flex items-center">
            <div className="bg-orange-100 p-3 rounded-md"><ShoppingCart className="h-6 w-6 text-orange-600" /></div>
            <div className="ml-5"><dt className="text-xs font-medium text-gray-500 uppercase tracking-wider">Cart Activity</dt><dd className="text-lg font-bold text-gray-900">{stats.totalCartActions}</dd></div>
          </div>
        </div>
        <div className="bg-white p-5 shadow rounded-lg border border-gray-100">
          <div className="flex items-center">
            <div className="bg-yellow-100 p-3 rounded-md"><Eye className="h-6 w-6 text-yellow-600" /></div>
            <div className="ml-5"><dt className="text-xs font-medium text-gray-500 uppercase tracking-wider">Page Views</dt><dd className="text-lg font-bold text-gray-900">{stats.totalViews}</dd></div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderProducts = () => (
    <div className="space-y-8 animate-in fade-in duration-300">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            {/* Add Product Form */}
            <div className="bg-white shadow rounded-lg border border-gray-100 p-6">
                <h3 className="text-xl font-serif font-medium text-gray-900 mb-6 flex items-center gap-2">
                    <Plus className="h-6 w-6 text-[#D4AF37]" /> Add New Product
                </h3>
                <form onSubmit={handleProductSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Product Name *</label>
                            <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" placeholder="e.g. Royal Oud" required />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Price ($) *</label>
                            <input type="number" step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" placeholder="0.00" required />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Category</label>
                            <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900">
                                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Stock Level</label>
                            <input type="number" value={stock} onChange={(e) => setStock(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" required />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Discount (%)</label>
                            <input type="number" value={discount} onChange={(e) => setDiscount(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" placeholder="e.g. 10" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Sale End Time</label>
                            <input type="datetime-local" value={saleEndTime} onChange={(e) => setSaleEndTime(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1 flex items-center gap-2">
                           <Sparkles className="h-3 w-3 text-[#D4AF37]" /> AI Description Generator
                        </label>
                        <div className="flex gap-2 mb-2">
                            <input type="text" value={keywords} onChange={(e) => setKeywords(e.target.value)} placeholder="Enter keywords (e.g. woody, amber, night wear)" className="flex-1 border rounded px-3 py-2 text-sm bg-white text-gray-900" />
                            <button type="button" onClick={handleGenerateDescription} disabled={isGenerating} className="bg-black text-white px-4 py-2 rounded text-xs font-bold hover:bg-[#D4AF37] disabled:opacity-50">
                                {isGenerating ? <Loader2 className="h-4 w-4 animate-spin" /> : 'AI Generate'}
                            </button>
                        </div>
                        <textarea rows={4} value={description} onChange={(e) => setDescription(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" placeholder="Product description..." required />
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Product Image *</label>
                        <div className="mt-1 flex items-center gap-4">
                            {image && <img src={image} className="h-20 w-20 object-cover rounded border" />}
                            <label className="cursor-pointer bg-gray-50 border-2 border-dashed border-gray-300 px-4 py-2 rounded flex items-center gap-2 text-xs font-bold text-gray-600 hover:border-[#D4AF37]">
                                <Upload className="h-4 w-4" /> {image ? 'Change Image' : 'Upload Image'}
                                <input type="file" className="sr-only" onChange={handleProductImageUpload} accept="image/*" />
                            </label>
                        </div>
                    </div>

                    <div className="flex items-center gap-2 py-2">
                        <input type="checkbox" id="featured" checked={isFeatured} onChange={(e) => setIsFeatured(e.target.checked)} className="h-4 w-4 text-[#D4AF37]" />
                        <label htmlFor="featured" className="text-sm font-medium text-gray-700">Mark as Featured Product</label>
                    </div>

                    <button type="submit" className="w-full bg-black text-white py-4 rounded text-xs font-bold uppercase tracking-widest hover:bg-[#D4AF37] transition-all">Save Product</button>
                </form>
            </div>

            {/* Product List */}
            <div className="bg-white shadow rounded-lg border border-gray-100 p-6 h-fit sticky top-8">
                <h3 className="text-xl font-serif font-medium text-gray-900 mb-6 flex items-center gap-2">
                    <Package className="h-6 w-6 text-[#D4AF37]" /> Current Inventory
                </h3>
                <div className="max-h-[600px] overflow-y-auto pr-2 space-y-4">
                    {products.map(product => (
                        <div key={product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-100 group">
                            <div className="flex items-center gap-3">
                                <img src={product.image} className="h-12 w-12 rounded object-cover" />
                                <div>
                                    <p className="text-sm font-bold text-gray-900">{product.name}</p>
                                    <p className="text-xs text-gray-500">${product.price.toFixed(2)} | {product.category}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="text-right">
                                    <label className="block text-[10px] uppercase text-gray-400 font-bold">Stock</label>
                                    <input type="number" className="w-16 border rounded px-1 py-1 text-xs text-center bg-white" value={product.stock} onChange={(e) => handleStockChange(product, e.target.value)} />
                                </div>
                                <button onClick={() => onDeleteProduct(product.id)} className="text-red-400 hover:text-red-600 p-2"><Trash2 className="h-4 w-4" /></button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
  );

  const renderDesign = () => (
    <div className="space-y-8 animate-in fade-in duration-300">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="bg-white shadow rounded-lg border border-gray-100 p-6 sticky top-8">
            <h3 className="text-lg font-serif font-medium text-gray-900 mb-6 flex items-center gap-2">
              <Palette className="h-5 w-5 text-[#D4AF37]" /> Add New Banner
            </h3>
            <form onSubmit={handleAddBannerSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Banner Title</label>
                <input type="text" value={bannerTitle} onChange={(e) => setBannerTitle(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" placeholder="e.g. Summer Collection" required />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Subtitle</label>
                <input type="text" value={bannerSubtitle} onChange={(e) => setBannerSubtitle(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" placeholder="e.g. Up to 50% Off" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Banner Image</label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md relative overflow-hidden group">
                   {bannerImage ? (
                      <div className="relative w-full h-32">
                        <img src={bannerImage} className="w-full h-full object-cover rounded" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <label className="cursor-pointer text-white text-xs font-bold flex items-center gap-1">
                                <Upload className="h-4 w-4" /> Change Image
                                <input type="file" className="sr-only" onChange={handleBannerImageUpload} accept="image/*" />
                            </label>
                        </div>
                      </div>
                   ) : (
                      <div className="space-y-1 text-center">
                        <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="flex text-sm text-gray-600 justify-center">
                          <label className="relative cursor-pointer bg-white rounded-md font-medium text-[#D4AF37] hover:text-black">
                            <span>Upload a file</span>
                            <input type="file" className="sr-only" onChange={handleBannerImageUpload} accept="image/*" required />
                          </label>
                        </div>
                        <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
                      </div>
                   )}
                </div>
              </div>
              <button type="submit" className="w-full bg-black text-white py-3 rounded text-xs font-bold uppercase tracking-widest hover:bg-[#D4AF37] transition-all flex items-center justify-center gap-2">
                <Plus className="h-4 w-4" /> Add Banner
              </button>
            </form>
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="bg-white shadow rounded-lg border border-gray-100 p-6">
            <h3 className="text-lg font-serif font-medium text-gray-900 mb-6">Current Store Banners</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {banners.length === 0 ? (
                <p className="text-gray-500 italic col-span-2 text-center py-10">No banners added yet.</p>
              ) : (
                banners.map((banner) => (
                  <div key={banner.id} className="group relative border rounded-lg overflow-hidden bg-gray-50">
                    <img src={banner.image} className="w-full h-40 object-cover" />
                    <div className="p-4 bg-white">
                      <h4 className="font-bold text-gray-900 text-sm truncate uppercase tracking-widest">{banner.title}</h4>
                      <p className="text-xs text-gray-500 truncate">{banner.subtitle}</p>
                    </div>
                    <button onClick={() => onDeleteBanner(banner.id)} className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="max-w-4xl space-y-8 animate-in fade-in duration-300">
      <div className="bg-white shadow rounded-lg border border-gray-100 p-8">
        <h3 className="text-xl font-serif font-medium text-gray-900 mb-8 flex items-center gap-2">
          <Settings className="h-6 w-6 text-[#D4AF37]" /> Global Site Settings
        </h3>
        <form onSubmit={handleSettingsSubmit} className="space-y-8">
          <div className="pb-8 border-b border-gray-100">
            <label className="block text-sm font-bold text-gray-700 mb-4 uppercase tracking-widest">Store Logo</label>
            <div className="flex items-center gap-8">
               <div className="h-32 w-32 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center overflow-hidden bg-gray-50">
                  {logoImage ? <img src={logoImage} className="w-full h-full object-contain" /> : <ImageIcon className="h-10 w-10 text-gray-300" />}
               </div>
               <div className="space-y-2">
                  <label className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 cursor-pointer">
                    <Upload className="h-4 w-4 mr-2" /> Upload New Logo
                    <input type="file" className="sr-only" onChange={handleLogoUpload} accept="image/*" />
                  </label>
                  <p className="text-xs text-gray-500">Transparent PNG recommended.</p>
               </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Site Name</label>
              <input type="text" value={siteName} onChange={(e) => setSiteName(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" required />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Tagline</label>
              <input type="text" value={tagline} onChange={(e) => setTagline(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" required />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Contact Email</label>
              <input type="email" value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" required />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Contact Phone</label>
              <input type="text" value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" required />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Instagram URL</label>
              <input type="url" value={instagramUrl} onChange={(e) => setInstagramUrl(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Footer Description</label>
              <textarea rows={3} value={footerDescription} onChange={(e) => setFooterDescription(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" />
            </div>
          </div>

          <div className="pt-8 border-t border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Flat Shipping Cost ($)</label>
              <input type="number" value={shippingCost} onChange={(e) => setShippingCost(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Free Shipping Threshold ($)</label>
              <input type="number" value={freeShippingThreshold} onChange={(e) => setFreeShippingThreshold(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Announcement Message</label>
              <input type="text" value={topBarMessage} onChange={(e) => setTopBarMessage(e.target.value)} className="w-full border rounded px-3 py-2 text-sm bg-white text-gray-900" />
            </div>
          </div>

          <button type="submit" className="w-full bg-[#D4AF37] text-white py-4 rounded text-xs font-bold uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-2 shadow-lg">
            <Save className="h-5 w-5" /> Save Site Configuration
          </button>
        </form>
      </div>
    </div>
  );

  const renderOrderDetail = (order: Order) => (
    <div className="space-y-6 animate-in fade-in duration-300">
        <button onClick={() => setSelectedOrderId(null)} className="flex items-center text-sm font-medium text-gray-600 hover:text-black transition-colors"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Orders</button>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
                 <div className="bg-white shadow rounded-lg border border-gray-100 overflow-hidden">
                    <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50"><h3 className="text-lg font-medium text-gray-900">Items in Order {order.id}</h3></div>
                    <ul className="divide-y divide-gray-100">
                        {order.items.map((item, idx) => (
                            <li key={idx} className="p-4 flex items-center">
                                <img src={item.image} alt={item.name} className="h-16 w-16 object-cover rounded border border-gray-200" />
                                <div className="ml-4 flex-1"><h4 className="text-sm font-bold text-gray-900 uppercase tracking-widest">{item.name}</h4><p className="text-xs text-gray-500">{item.category}</p></div>
                                <div className="text-right"><p className="text-sm font-medium text-gray-900">${item.price.toFixed(2)} x {item.quantity}</p></div>
                            </li>
                        ))}
                    </ul>
                    <div className="bg-gray-50 px-6 py-4 border-t border-gray-100 text-right">
                        <p className="text-sm text-gray-600">Subtotal: ${(order.subtotal || order.total).toFixed(2)}</p>
                        <p className="text-sm text-gray-600">Shipping: ${order.shippingCost?.toFixed(2) || '0.00'}</p>
                        <p className="text-xl font-bold text-[#D4AF37] mt-1">Total: ${order.total.toFixed(2)}</p>
                    </div>
                 </div>
            </div>
            <div className="space-y-6">
                <div className="bg-white shadow rounded-lg border border-gray-100 p-6">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Customer Info</h3>
                    <p className="text-sm font-bold text-gray-900 mb-1">{order.customerName}</p>
                    <p className="text-sm text-gray-600 mb-4">{order.email}</p>
                    <div className="bg-gray-50 p-4 rounded text-sm text-gray-700 space-y-2 border border-gray-100">
                        <p><strong>Phone:</strong> {order.customerPhone}</p>
                        <p><strong>Address:</strong> {order.shippingAddress}</p>
                    </div>
                </div>
                <div className="bg-white shadow rounded-lg border border-gray-100 p-6">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Update Status</h3>
                    <select value={order.status} onChange={(e) => onUpdateOrderStatus(order.id, e.target.value as OrderStatus)} className="w-full text-sm font-medium rounded-md p-2 border border-gray-300 bg-white">
                        {Object.values(OrderStatus).map((s) => (<option key={s} value={s}>{s}</option>))}
                    </select>
                </div>
            </div>
        </div>
    </div>
  );

  const renderOrders = () => {
    if (selectedOrderId) { const order = orders.find(o => o.id === selectedOrderId); if (order) return renderOrderDetail(order); }
    return (
        <div className="bg-white shadow rounded-lg border border-gray-100 overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50"><tr><th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-widest">Order ID</th><th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-widest">Customer</th><th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-widest">Total</th><th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-widest">Status</th></tr></thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    {orders.length === 0 ? (
                        <tr><td colSpan={4} className="px-6 py-10 text-center text-gray-500 italic">No orders yet.</td></tr>
                    ) : (
                        orders.map((order) => (
                            <tr key={order.id} onClick={() => setSelectedOrderId(order.id)} className="hover:bg-gray-50 cursor-pointer transition-colors">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-[#D4AF37]">{order.id}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">{order.customerName}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">${order.total.toFixed(2)}</td>
                                <td className="px-6 py-4 whitespace-nowrap"><span className={`inline-flex px-3 py-1 text-xs font-bold uppercase tracking-tighter rounded-full bg-yellow-100 text-yellow-800 border border-yellow-200`}>{order.status}</span></td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      <div className="md:w-64 bg-white border-r border-gray-200 p-6 sticky top-0 md:h-screen">
        <h2 className="text-[#D4AF37] font-script text-4xl mb-8">Admin</h2>
        <nav className="space-y-2">
          {['OVERVIEW', 'ORDERS', 'PRODUCTS', 'DESIGN', 'SETTINGS'].map((tab) => (
            <button key={tab} onClick={() => setActiveTab(tab as AdminTab)} className={`w-full text-left px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] rounded transition-all ${activeTab === tab ? 'bg-black text-white shadow-lg' : 'text-gray-500 hover:bg-gray-50'}`}>
              {tab}
            </button>
          ))}
        </nav>
      </div>
      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
            {activeTab === 'OVERVIEW' && renderOverview()}
            {activeTab === 'ORDERS' && renderOrders()}
            {activeTab === 'PRODUCTS' && renderProducts()}
            {activeTab === 'DESIGN' && renderDesign()}
            {activeTab === 'SETTINGS' && renderSettings()}
        </div>
      </div>
    </div>
  );
};
