import { Order } from '../types';

export const sendOrderEmails = async (order: Order): Promise<void> => {
  // Simulate network latency for a realistic effect
  await new Promise(resolve => setTimeout(resolve, 800));

  console.group('%c 📧 EMAIL SYSTEM SIMULATION ', 'background: #222; color: #bada55; font-size: 12px; padding: 4px; border-radius: 4px;');

  // ---------------------------------------------------------
  // 1. Customer Confirmation Email
  // ---------------------------------------------------------
  const customerSubject = `Order Confirmation #${order.id} - Fragoma By Salma Rahat`;
  const customerBody = `
    Dear ${order.customerName},

    Thank you for shopping with Fragoma! Your order has been received and is currently being processed.

    --------------------------------------------------
    ORDER SUMMARY
    --------------------------------------------------
    Order ID:     ${order.id}
    Date:         ${new Date(order.date).toLocaleDateString()}
    Status:       ${order.status}

    ITEMS:
    ${order.items.map(item => `• ${item.name} (x${item.quantity}) - $${(item.price * item.quantity).toFixed(2)}`).join('\n    ')}

    --------------------------------------------------
    Subtotal:     $${(order.subtotal || order.total).toFixed(2)}
    ${order.discountAmount ? `Discount:    -$${order.discountAmount.toFixed(2)} (${order.discountCode})` : ''}
    Shipping:     Free
    TOTAL:        $${order.total.toFixed(2)}
    --------------------------------------------------

    We will notify you via email once your items have shipped.

    Warm regards,
    The Fragoma Team
  `;

  console.log(`%c[TO CUSTOMER: ${order.email || 'guest@example.com'}]`, 'color: #3b82f6; font-weight: bold;');
  console.log(`%cSubject: ${customerSubject}`, 'font-weight: bold;');
  console.log(customerBody);

  // ---------------------------------------------------------
  // 2. Admin Notification Email
  // ---------------------------------------------------------
  const adminSubject = `[ADMIN] New Order Received: ${order.id}`;
  const adminBody = `
    A new order has been placed on the store.

    Customer:   ${order.customerName} (${order.email})
    Order ID:   ${order.id}
    Value:      $${order.total.toFixed(2)}
    Items:      ${order.items.length}

    Please log in to the Admin Dashboard to fulfill this order.
  `;

  console.log(`%c[TO ADMIN: admin@fragoma.com]`, 'color: #f59e0b; font-weight: bold;');
  console.log(`%cSubject: ${adminSubject}`, 'font-weight: bold;');
  console.log(adminBody);

  console.groupEnd();
  return Promise.resolve();
};