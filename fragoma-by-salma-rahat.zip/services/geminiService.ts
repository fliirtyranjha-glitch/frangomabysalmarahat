import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateProductDescription = async (productName: string, category: string, features: string): Promise<string> => {
  try {
    const prompt = `
      You are a professional e-commerce copywriter.
      Write a compelling, short, and SEO-friendly product description (max 60 words) for a product.
      
      Product Name: ${productName}
      Category: ${category}
      Key Features/Keywords: ${features}
      
      Tone: Professional, persuasive, and exciting.
      Do not use markdown formatting like **bold**. Just plain text.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Could not generate description.";
  } catch (error) {
    console.error("Error generating description:", error);
    return "Error generating description. Please try again.";
  }
};