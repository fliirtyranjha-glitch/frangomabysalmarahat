
export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  description: string;
  image: string;
  featured: boolean;
  stock: number;
  discount?: number;
  saleEndTime?: string;
  seoTitle?: string;
  metaDescription?: string;
  seoKeywords?: string;
  reviews?: Review[];
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  image: string;
}

export interface SiteSettings {
  siteName: string;
  tagline: string;
  logoImage: string | null;
  contactEmail: string;
  contactPhone: string;
  instagramUrl: string;
  footerDescription: string;
  shippingCost: number;
  freeShippingThreshold: number;
  topBarMessage: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface DiscountCode {
  code: string;
  type: 'PERCENTAGE' | 'FIXED';
  value: number;
}

export interface Order {
  id: string;
  customerName: string;
  items: CartItem[];
  total: number;
  subtotal?: number;
  discountAmount?: number;
  discountCode?: string;
  shippingCost?: number;
  shippingAddress?: string;
  customerPhone?: string;
  status: OrderStatus;
  date: string;
  email?: string;
}

export enum OrderStatus {
  PENDING = 'Pending',
  PROCESSING = 'Processing',
  SHIPPED = 'Shipped',
  DELIVERED = 'Delivered',
  CANCELLED = 'Cancelled'
}

export interface DashboardStats {
  totalViews: number;
  uniqueVisitors: number;
  totalSales: number;
  totalOrders: number;
  totalCartActions: number;
}

export enum View {
  STORE = 'STORE',
  ADMIN = 'ADMIN',
  CART = 'CART',
  ABOUT = 'ABOUT',
  PRIVACY = 'PRIVACY',
  TERMS = 'TERMS',
  SHIPPING = 'SHIPPING',
  LOGIN = 'LOGIN',
  PRODUCT_DETAIL = 'PRODUCT_DETAIL'
}

export const CATEGORIES = [
  "Fragrances",
  "Oils",
  "Beauty",
  "Gifts"
];
